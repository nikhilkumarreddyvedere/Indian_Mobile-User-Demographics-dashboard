
# coding: utf-8

# In[101]:

import pandas as pd
import numpy as np

df1 = pd.read_csv("events.csv")

sample1 = df1

df2= pd.read_csv("out.csv")

sample2 = df2

sample1['longitude'] = sample2['Longitude']
sample1['latitude'] = sample2['Latitude']

final = np.round(sample1, decimals=2)

final_Null= final.dropna()

print(final_Null)

df1.to_csv('events.csv', index=False)


# In[ ]:



